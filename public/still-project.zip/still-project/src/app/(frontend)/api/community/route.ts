import { getPayload } from 'payload'
import config from '@payload-config'
import { appAuth } from '@/lib/app-auth'

export async function GET() {
  try {
    const payload = await getPayload({ config })
    const user = await appAuth.currentUser()
    const cards = await payload.find({ collection: 'cards', overrideAccess: false, user, depth: 0, limit: 100, sort: '-createdAt' })
    const swipes = user ? await payload.find({ collection: 'swipes', overrideAccess: false, user, depth: 1, limit: 100, sort: '-createdAt' }) : { docs: [] }
    return Response.json({ cards: cards.docs, swipes: swipes.docs, user: user ? { name: user.name, id: user.id } : null })
  } catch { return Response.json({ error: 'Your cards could not be loaded. Please try again.' }, { status: 500 }) }
}
export async function POST(request: Request) {
  try {
    if (request.headers.get('sec-fetch-site') === 'cross-site') return Response.json({ error: 'Request not allowed.' }, { status: 403 })
    const body = await request.json()
    const payload = await getPayload({ config })
    if (body.operation === 'logout') { await appAuth.logout(); return Response.json({ success: true }) }
    if (body.operation === 'login' || body.operation === 'signup') {
      const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : ''
      const password = typeof body.password === 'string' ? body.password : ''
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8 || password.length > 128) return Response.json({ error: 'Enter a valid email and a password of at least 8 characters.' }, { status: 400 })
      if (body.operation === 'signup') {
        const name = typeof body.name === 'string' ? body.name.trim() : ''
        if (!name || name.length > 60) return Response.json({ error: 'Please enter your name (up to 60 characters).' }, { status: 400 })
        await payload.create({ collection: 'users', overrideAccess: false, data: { email, password, name } })
      }
      await appAuth.login(email, password)
      return Response.json({ success: true })
    }
    const user = await appAuth.currentUser()
    if (!user) return Response.json({ error: 'Log in to make this moment yours.' }, { status: 401 })
    if (body.operation === 'post') {
      const text = typeof body.text === 'string' ? body.text.trim() : ''
      if (text.length < 10 || text.length > 500 || !['Life', 'Creativity', 'Growth', 'Connection'].includes(body.topic)) return Response.json({ error: 'Write 10–500 characters and choose a topic.' }, { status: 400 })
      await payload.create({ collection: 'cards', overrideAccess: false, user, data: { text, topic: body.topic } })
    } else if (body.operation === 'swipe') {
      if (!['pass', 'save', 'resonate'].includes(body.action) || (typeof body.card !== 'string' && typeof body.card !== 'number')) return Response.json({ error: 'Choose a valid card and action.' }, { status: 400 })
      const swipe = await payload.create({ collection: 'swipes', overrideAccess: false, user, data: { card: body.card, action: body.action } })
      return Response.json({ success: true, id: swipe.id })
    } else if (body.operation === 'undo') {
      if (typeof body.id !== 'string' && typeof body.id !== 'number') return Response.json({ error: 'Invalid action.' }, { status: 400 })
      await payload.delete({ collection: 'swipes', id: body.id, overrideAccess: false, user })
    } else return Response.json({ error: 'Unknown action.' }, { status: 400 })
    return Response.json({ success: true })
  } catch { return Response.json({ error: 'That didn’t work. Check your details and try again.' }, { status: 400 }) }
}
