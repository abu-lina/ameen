'use client'

import { useEffect, useState, useRef, type FormEvent } from 'react'
import { swipeAction } from '@/lib/swipe'

type Card = { id: string | number; text: string; topic: string; authorName?: string }
type Swipe = { id: string | number; card: Card | string | number; action: string }
function Icon({ name, className = '' }: { name: string; className?: string }) {
  const paths: Record<string, React.ReactNode> = {
    discover: <><rect x="4" y="5" width="14" height="16" rx="3" transform="rotate(-12 4 5)" /><path d="M10 3h7a3 3 0 0 1 3 3v12" /></>,
    save: <path d="M6 4h12v17l-6-4-6 4z" />, heart: <path d="M20.8 5.6a5.5 5.5 0 0 0-8.8.6 5.5 5.5 0 0 0-8.8-.6C-1 11 12 20 12 20s13-9 8.8-14.4Z" />,
    plus: <path d="M12 5v14M5 12h14" />, arrow: <path d="m9 5 7 7-7 7M4 12h12" />,
    close: <path d="m6 6 12 12M6 18 18 6" />, leaf: <><path d="M19 3C6 2 2 8 6 15c7 4 13 0 13-12Z" /><path d="M4 21 15 9" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21v-2a8 8 0 0 1 16 0v2" /></>,
    undo: <><path d="m8 4-5 5 5 5M3 9h10a7 7 0 0 1 0 14" /></>,
  }
  return <svg className={className} width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] || paths.discover}</svg>
}
export default function HomePage() {
  const [view, setView] = useState('Discover')
  const [topic, setTopic] = useState('All thoughts')
  const [cards, setCards] = useState<Card[]>([])
  const [swipes, setSwipes] = useState<Swipe[]>([])
  const [user, setUser] = useState<{name: string} | null>(null)
  const [modal, setModal] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [loaded, setLoaded] = useState(false)
  const [message, setMessage] = useState('')
  const [drag, setDrag] = useState({ x: 0, y: 0 })
  const start = useRef<{x: number; y: number; pointerId: number} | null>(null)
  const submitting = useRef(false)
  const [last, setLast] = useState<string | number | null>(null)
  async function load() {
    try {
      const r = await fetch('/api/community')
      const d = await r.json()
      if (!r.ok) throw new Error(d.error)
      setCards(d.cards); setSwipes(d.swipes); setUser(d.user)
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Unable to load cards.') }
    setLoaded(true)
  }
  useEffect(() => { void load() }, [])
  async function send(data: Record<string, unknown>) {
    const r = await fetch('/api/community', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
    const d = await r.json()
    if (!r.ok) throw new Error(d.error)
    return d
  }
  const seen = new Set(swipes.map(s => typeof s.card === 'object' ? s.card.id : s.card))
  const deck = cards.filter(c => (topic === 'All thoughts' || c.topic === topic) && !seen.has(c.id))
  const card = deck[0]
  async function act(action: string) {
    if (!card || busy || submitting.current) return
    if (!user) { setMessage('Log in to save your swipe and continue.'); setModal('login'); return }
    submitting.current = true
    setBusy(true)
    try { const d = await send({ operation: 'swipe', card: card.id, action }); setLast(d.id); setMessage(action === 'pass' ? 'Passed, without judgment.' : action === 'save' ? 'Saved for a quieter moment.' : 'A little resonance, sent.'); await load() }
    catch (e) { setMessage((e as Error).message) }
    submitting.current = false
    setBusy(false); setDrag({ x: 0, y: 0 })
  }
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage('')
    try { await send({ operation: modal, ...Object.fromEntries(new FormData(e.currentTarget)) }); setModal(null); await load(); if (modal === 'post') setMessage('Your thought is out in the world.') }
    catch (e) { setMessage((e as Error).message) }
    setBusy(false)
  }
  const saved = swipes.filter(s => s.action === (view === 'Saved' ? 'save' : 'resonate') && typeof s.card === 'object')
  return <div className="min-h-screen bg-[#f8f9f5] text-[#263f35]">
    <a href="/still-project.zip" download="still-project.zip" className="fixed bottom-24 right-5 z-40 rounded-full border border-[#dce2d6] bg-[#345440] px-5 py-3 text-sm font-medium text-white shadow-lg md:bottom-6">
      Download project ZIP
    </a>
    <aside className="fixed inset-y-0 left-0 z-20 hidden w-[238px] flex-col border-r border-[#e5e8df] bg-[#fcfcf9] px-7 py-10 md:flex">
      <a href="/" className="flex items-center gap-2.5 text-[32px] font-semibold tracking-[-2px]"><Icon name="leaf" className="h-9 w-9" />still<span className="text-[#a0b39a]">.</span></a>
      <p className="mt-2 pl-1 text-[11px] tracking-[.11em] text-[#8a9389]">A LITTLE SPACE TO CONNECT</p>
      <nav className="mt-14 space-y-2">{[['Discover','discover'],['Saved','save'],['Resonated','heart']].map(([label, icon]) => <button key={label} onClick={() => setView(label)} className={`flex w-full items-center gap-3 rounded-xl px-4 py-3.5 text-sm transition ${view === label ? 'bg-[#e9eee5] font-semibold text-[#365343]' : 'text-[#7c857b] hover:bg-[#f0f2eb]'}`}><Icon name={icon} />{label}{label === 'Saved' && swipes.filter(s => s.action === 'save').length > 0 && <span className="ml-auto text-xs">{swipes.filter(s => s.action === 'save').length}</span>}</button>)}</nav>
      <button onClick={() => setModal(user ? 'post' : 'login')} className="mt-9 flex items-center justify-center gap-2 rounded-xl bg-[#345440] py-3.5 text-sm font-medium text-white hover:bg-[#284332]"><Icon name="plus" />Create a card</button>
      <div className="mt-auto border-t border-[#e5e8df] pt-6"><p className="font-serif text-lg italic leading-relaxed text-[#86917d]">Less scrolling.<br />More feeling.</p><button onClick={async () => { if (user) { await send({ operation: 'logout' }); await load() } else setModal('login') }} className="mt-8 flex items-center gap-3 text-sm"><span className="grid h-9 w-9 place-items-center rounded-full border border-[#dce2d6]"><Icon name="user" /></span>{user ? `${user.name} · Log out` : 'Log in / Sign up'}</button></div>
    </aside>
    <div className="md:ml-[238px]">
      <header className="flex h-[86px] items-center justify-between border-b border-[#e5e8df] px-6 lg:px-12"><span className="text-sm font-medium"><span className="md:hidden font-serif text-2xl">still. / </span>{view}</span><div className="flex items-center gap-6"><span className="hidden items-center gap-2 text-xs text-[#909889] sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#91a784]" />A slower kind of social.</span><button onClick={() => setModal(user ? 'post' : 'login')} className="flex items-center gap-2 rounded-full border border-[#dce2d6] px-4 py-2 text-xs"><Icon name={user ? 'plus' : 'user'} />{user ? 'Share a thought' : 'Log in'}<span className="hidden sm:inline"> {!user && '↗'}</span></button></div></header>
      <main className="mx-auto max-w-[1100px] px-5 pb-24 pt-10 sm:px-10 lg:pt-12">
        <div className="text-center"><div className="mb-4 flex items-center justify-center gap-2 text-[10px] font-medium tracking-[.22em] text-[#8b967f]"><Icon name="leaf" className="h-3.5 w-3.5" /> ROOM FOR A LITTLE PERSPECTIVE</div><h1 className="font-serif text-[37px] leading-tight tracking-[-1.3px] sm:text-[43px]">{view === 'Discover' ? 'One thought at a time.' : view === 'Saved' ? 'Thoughts to come back to.' : 'Something stayed with you.'}</h1><p className="mt-3 text-sm text-[#899084]">No rush. No noise. Just words that might stay with you.</p></div>
        {view === 'Discover' ? <>
          <div className="mb-9 mt-8 flex justify-center gap-2 overflow-x-auto py-1">{['All thoughts','Life','Creativity','Growth','Connection'].map(t => <button key={t} onClick={() => setTopic(t)} className={`whitespace-nowrap rounded-full px-4 py-2 text-xs transition ${topic === t ? 'bg-[#e4eadc] font-medium text-[#42583a]' : 'text-[#8c9386] hover:bg-[#edf0e7]'}`}>{t}</button>)}</div>
          <div className="relative mx-auto w-full max-w-[445px]">
            <div className="absolute inset-0 translate-y-4 rotate-[-3deg] rounded-[23px] border border-[#ddd9c8] bg-[#eeeee1]" /><div className="absolute inset-0 translate-y-2 rotate-[2deg] rounded-[23px] border border-[#dedccd] bg-[#f3f1e5]" />
            <article className="relative flex min-h-[385px] touch-none select-none cursor-grab active:cursor-grabbing flex-col rounded-[22px] border border-[#e2dfcf] bg-[#f8f5e9] p-8 shadow-[0_12px_35px_-20px_#626a48] sm:min-h-[410px] sm:p-10" style={{ transform: `translate(${drag.x}px, ${drag.y}px) rotate(${drag.x / 25}deg)` }}
              onPointerDown={e => { if (!card || busy || submitting.current || !e.isPrimary || e.button !== 0) return; e.currentTarget.setPointerCapture(e.pointerId); start.current = { x: e.clientX, y: e.clientY, pointerId: e.pointerId } }}
              onPointerMove={e => { if (start.current?.pointerId === e.pointerId) setDrag({ x: e.clientX - start.current.x, y: Math.min(0, e.clientY - start.current.y) }) }}
              onPointerCancel={() => { start.current = null; setDrag({ x: 0, y: 0 }) }}
              onLostPointerCapture={() => { start.current = null; setDrag({ x: 0, y: 0 }) }}
              onPointerUp={e => {
                const origin = start.current
                if (!origin || origin.pointerId !== e.pointerId) return
                start.current = null
                const action = swipeAction(e.clientX - origin.x, e.clientY - origin.y)
                setDrag({ x: 0, y: 0 })
                if (action) void act(action)
              }}>
              <div className="flex items-center justify-between"><span className="rounded-full border border-[#dbddc9] px-3 py-1 text-[10px] tracking-wide text-[#7a8665]">{card?.topic || 'A fresh beginning'}</span><span className="text-[#a9ae95]">•••</span></div>
              <div className="flex flex-1 items-center py-8"><h2 className="font-serif text-[29px] leading-[1.4] tracking-[-.4px] sm:text-[32px]">{card?.text || (loaded ? 'Every meaningful connection starts with a single thought. What’s on your mind?' : 'A little stillness is on its way.')}</h2></div>
              <div className="flex items-center gap-3 border-t border-[#e3e1d2] pt-5"><div className="grid h-8 w-8 place-items-center rounded-full bg-[#e5e7d4] font-serif text-sm">{(card?.authorName || 'Still')[0]}</div><div><p className="text-xs font-medium">{card?.authorName || 'A note from still'}</p><p className="mt-0.5 text-[10px] text-[#969a85]">{card ? 'Shared with a little intention' : 'Be the first to share a card'}</p></div><Icon name="leaf" className="ml-auto h-5 w-5 text-[#a2ab88]" /></div>
              {(Math.abs(drag.x) > 25 || drag.y < -25) && <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-3 rounded-[22px] bg-[#e7ecdc]/90 text-2xl font-medium"><span>{-drag.y > Math.abs(drag.x) ? 'Save for later' : drag.x > 0 ? 'This resonates' : 'Pass, gently'}</span><span className="text-sm font-normal">{swipeAction(drag.x, drag.y) ? 'Release to confirm' : 'Keep dragging to confirm'}</span></div>}
            </article>
          </div>
          <div className="mt-10 flex items-start justify-center gap-8 sm:gap-11">{[['pass','close','Pass','Swipe left'],['save','save','Save','Swipe up'],['resonate','heart','Resonates','Swipe right']].map(([action, icon, label, hint]) => <button key={action} disabled={busy || !card} onClick={() => void act(action)} className="group flex flex-col items-center disabled:opacity-40"><span className={`mb-3 grid h-[58px] w-[58px] place-items-center rounded-full border transition group-hover:-translate-y-1 ${action === 'resonate' ? 'border-[#36533f] bg-[#36533f] text-white' : action === 'save' ? 'border-[#dce1cf] bg-[#edf0e3] text-[#73815d]' : 'border-[#e1e4dc] bg-white text-[#9b9e93]'}`}><Icon name={icon} /></span><span className="text-xs font-medium">{label}</span><span className="mt-1 text-[10px] text-[#a0a597]">{hint}</span></button>)}</div>
          {!card && loaded && <button onClick={() => setModal(user ? 'post' : 'login')} className="mx-auto mt-5 block text-sm underline underline-offset-4">Share the next thought</button>}
          <p className="mt-8 text-center text-[11px] text-[#9aA18f]">{busy ? 'Saving your choice…' : 'Drag left, right, or up. Release when the card says to confirm.'}</p>
        </> : <div className="mx-auto mt-10 max-w-xl space-y-4">{saved.length ? saved.map(s => { const c = s.card as Card; return <article key={s.id} className="rounded-2xl border border-[#e2dfcf] bg-[#f8f5e9] p-7"><span className="text-xs text-[#879373]">{c.topic}</span><p className="my-4 font-serif text-2xl">{c.text}</p><span className="text-xs text-[#929887]">{c.authorName || 'A member of still'}</span></article> }) : <div className="rounded-2xl border border-dashed border-[#d9dfd1] p-12 text-center"><Icon name="save" className="mx-auto mb-4 text-[#8b9c7e]" /><h2 className="font-serif text-2xl">A little space for what matters.</h2><p className="mt-3 text-sm text-[#899084]">{user ? 'The thoughts you connect with will live here.' : 'Log in to keep the thoughts that stay with you.'}</p><button onClick={() => user ? setView('Discover') : setModal('login')} className="mt-5 text-sm underline underline-offset-4">{user ? 'Discover thoughts' : 'Log in'}</button></div>}</div>}
        <div className="mx-auto mt-9 flex max-w-[445px] items-center justify-center gap-2 border-t border-[#e3e7dc] pt-5 text-[11px] text-[#9ba18f]"><Icon name="leaf" className="h-3.5 w-3.5" />Made for connection, not consumption.</div>
        {message && <div role="status" className="mx-auto mt-5 flex max-w-lg items-center justify-center gap-4 rounded-xl bg-[#e8eddf] p-3 text-center text-xs">{message}{last && <button className="flex items-center gap-1 font-semibold underline" onClick={async () => { try { await send({ operation: 'undo', id: last }); setLast(null); setMessage('A little room to reconsider.'); await load() } catch(e) { setMessage((e as Error).message) } }}><Icon name="undo" className="h-3 w-3" />Undo</button>}<button aria-label="Dismiss message" onClick={() => setMessage('')}><Icon name="close" className="h-3 w-3" /></button></div>}
      </main>
    </div>
    <nav className="fixed inset-x-0 bottom-0 z-20 flex justify-around border-t border-[#e0e5d8] bg-[#fcfcf9] py-3 md:hidden">{[['Discover','discover'],['Saved','save'],['Resonated','heart']].map(([v,i]) => <button key={v} onClick={() => setView(v)} className={`flex flex-col items-center gap-1 text-[10px] ${view === v ? 'text-[#345440]' : 'text-[#929987]'}`}><Icon name={i} />{v}</button>)}</nav>
    {modal && <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#22372c]/35 p-5 backdrop-blur-sm" onClick={() => setModal(null)}><section role="dialog" aria-modal="true" aria-labelledby="dialog-title" onClick={e => e.stopPropagation()} className="relative w-full max-w-md rounded-3xl bg-[#fcfcf7] p-8 shadow-xl"><button aria-label="Close dialog" onClick={() => setModal(null)} className="absolute right-5 top-5"><Icon name="close" /></button><Icon name="leaf" className="mb-5 h-8 w-8" /><h2 id="dialog-title" className="font-serif text-3xl">{modal === 'post' ? 'Leave a little thought.' : modal === 'signup' ? 'Find your space.' : 'Welcome to still.'}</h2><p className="mb-6 mt-2 text-sm text-[#8c9484]">{modal === 'post' ? 'Something honest. Something that might find its person.' : 'A slower, more meaningful kind of connection.'}</p><form onSubmit={submit} className="space-y-4">{modal === 'post' ? <><label className="block text-xs">Your thought<textarea name="text" required minLength={10} maxLength={500} placeholder="Lately, I’ve been thinking..." className="mt-2 min-h-36 w-full rounded-xl border border-[#dfe4d6] bg-white p-4 text-base outline-[#779165]" /></label><label className="block text-xs">A little context<select name="topic" className="mt-2 w-full rounded-xl border border-[#dfe4d6] bg-white p-3 text-sm">{['Life','Creativity','Growth','Connection'].map(t => <option key={t}>{t}</option>)}</select></label></> : <>{modal === 'signup' && <label className="block text-xs">Your name<input name="name" required maxLength={60} autoComplete="name" className="mt-2 w-full rounded-xl border border-[#dfe4d6] bg-white p-3 text-sm" /></label>}<label className="block text-xs">Email address<input name="email" type="email" required autoComplete="email" className="mt-2 w-full rounded-xl border border-[#dfe4d6] bg-white p-3 text-sm" /></label><label className="block text-xs">Password<input name="password" type="password" required minLength={8} autoComplete={modal === 'signup' ? 'new-password' : 'current-password'} className="mt-2 w-full rounded-xl border border-[#dfe4d6] bg-white p-3 text-sm" /></label></>}<button disabled={busy} className="w-full rounded-xl bg-[#345440] p-3.5 text-sm text-white disabled:opacity-50">{busy ? 'One moment…' : modal === 'post' ? 'Share your card' : modal === 'signup' ? 'Create account' : 'Log in'}</button></form>{message && <p role="alert" className="mt-3 text-sm text-[#965948]">{message}</p>}{modal !== 'post' && <button onClick={() => { setModal(modal === 'signup' ? 'login' : 'signup'); setMessage('') }} className="mt-5 w-full text-center text-xs text-[#7a886c]">{modal === 'signup' ? 'Already have a space? Log in' : 'New here? Create an account'}</button>}</section></div>}
  </div>
}
