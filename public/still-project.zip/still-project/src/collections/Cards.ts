import type { Access, CollectionConfig } from 'payload'
const own: Access = ({ req }) => req.user?.collection === 'users' ? { author: { equals: req.user.id } } : false
export const Cards: CollectionConfig = {
  slug: 'cards', admin: { useAsTitle: 'text' },
  access: { read: () => true, create: ({ req }) => req.user?.collection === 'users', update: own, delete: own },
  hooks: { beforeValidate: [({ data, req, operation }) => {
    if (data && operation === 'create' && req.user?.collection === 'users') {
      data.author = req.user.id
      data.authorName = req.user.name
    }
    return data
  }] },
  fields: [
    { name: 'text', type: 'textarea', required: true, minLength: 10, maxLength: 500 },
    { name: 'topic', type: 'select', required: true, defaultValue: 'Life', options: ['Life', 'Creativity', 'Growth', 'Connection'] },
    { name: 'author', type: 'relationship', relationTo: 'users', access: { create: () => false, update: () => false } },
    { name: 'authorName', type: 'text', access: { create: () => false, update: () => false } },
  ],
}
