import type { Access, CollectionConfig } from 'payload'
const own: Access = ({ req }) => req.user?.collection === 'users' ? { id: { equals: req.user.id } } : false
export const Users: CollectionConfig = {
  slug: 'users', auth: true, admin: { useAsTitle: 'name' },
  access: { create: () => true, read: own, update: own, delete: own, admin: () => false },
  fields: [{ name: 'name', type: 'text', required: true, maxLength: 60 }],
}
